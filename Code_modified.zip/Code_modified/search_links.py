# Import the necessary libraries
from urllib.parse import urlparse, urljoin
import requests
from bs4 import BeautifulSoup
from langchain_community.document_loaders import AsyncHtmlLoader
from langchain_community.document_transformers.beautiful_soup_transformer import BeautifulSoupTransformer
from requests.auth import HTTPBasicAuth


# Get links from HTML
def get_links_from_html(html):
    def get_link(el):
        return el["href"]
    return list(map(get_link, BeautifulSoup(html, features="html.parser").select("a[href]")))


# Find links
def find_links(domain, url, searched_links, username=None, password=None):
    if ((not (url in searched_links)) and (not url.startswith("mailto:")) and (not url.startswith("tel:"))
            and (not ("javascript:" in url)) and (not url.endswith(".png")) and (not url.endswith(".jpg"))
            and (not url.endswith(".jpeg")) and ('/oauth/' not in url)
            and ('/#' not in url) and (urlparse(url).netloc == domain)):
        try:
            if username and password:
                requestObj = requests.get(url, auth=HTTPBasicAuth(username, password))
            else:
                requestObj = requests.get(url)
            searched_links.append(url)
            print(url)
            links = get_links_from_html(requestObj.text)
            for link in links:
                find_links(domain, urljoin(url, link), searched_links, username, password)
        except Exception as e:
            print(e)


# Search links
def search_links(domain, url, username=None, password=None):
    # Define the list of searched links
    searched_links = []
    # Find the links
    find_links(domain, url, searched_links)
    # Return the searched links
    return searched_links

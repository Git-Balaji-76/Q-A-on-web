"""# Imports
from chat_bot import start_chat, chat_bot
from create_index import create_index
from search_links import search_links

# # Define the domain and url
# domain = "developer-service.io"
# url = "https://developer-service.io"
#
# # Search for the link
# links = search_links(domain, url)
#
# # Index the links
# create_index(links)

# Start chat
chain = start_chat()

# Chat with the bot
question = input("\nHuman: ")
while question != "exit":
    chat_bot(chain, question)
    question = input("\nHuman: ")
    """
import streamlit as st
from search_links import search_links
from create_index import create_index
from chat_bot import start_chat, chat_bot
def main():
   
    st.header("VeeChat with your Website")

    enter_url = "https://developer-service.io/"
    domain = "developer-service.io"
   
    if enter_url:
        links = search_links(domain, enter_url)
        create_index(links)
        chain = start_chat()
        user_question = st.text_input("Ask a Question")
        if user_question:
            chat_bot(chain,user_question)



if __name__ == "__main__":
    main()
    
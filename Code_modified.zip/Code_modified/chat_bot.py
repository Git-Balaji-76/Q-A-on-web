import os

from decouple import config
from langchain.chains.conversational_retrieval.base import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory
from langchain_community.llms.ctransformers import CTransformers
from langchain_community.vectorstores.faiss import FAISS
from langchain_core.callbacks import StreamingStdOutCallbackHandler
from langchain_mistralai import MistralAIEmbeddings, ChatMistralAI
from langchain_openai import OpenAIEmbeddings,ChatOpenAI
import os
os.environ['OPENAI_API_KEY'] = "--------e"
# Get retriever from file index
def retrieve_from_index():
    db = FAISS.load_local("C:\ennvee_B\Code\Webpage project\Q&A_LLM\SiteChatBotCPU",
                          embeddings=OpenAIEmbeddings(),
                          allow_dangerous_deserialization=True)
    
    retriever = db.as_retriever(
        search_type="mmr",
        search_kwargs={"k": 8},
        max_tokens_limit=4097,
    )
    return retriever


# Start chat
def start_chat():
    retriever = retrieve_from_index()
    memory = ConversationBufferMemory(memory_key="chat_history", input_key='question', output_key='answer',
                                      return_messages=True)
    # Uncomment to use MistralAI API
    # model = ChatMistralAI(model="open-mixtral-8x7b", mistral_api_key=config('MISTRAL_API_KEY'), temperature=0.7)
    # Using CTransformers to use MistralAI model from Hugging Face on the CPU
    model = CTransformers(model="TheBloke/Mistral-7B-Instruct-v0.2-GGUF",
                          model_file="mistral-7b-instruct-v0.2.Q4_K_M.gguf",
                          config={'max_new_tokens': 4096, 'temperature': 0.7, 'context_length': 4096},
                          threads=os.cpu_count())
    """model='gpt-3.5-turbo'"""
    # Load LLM
    qa_chain = ConversationalRetrievalChain.from_llm(model, retriever=retriever,
                                                     return_source_documents=True,
                                                     memory=memory)
    return qa_chain


def chat_bot(chain, question):
    print("Loading answers...")
    result = chain.invoke(question)
    print(f"\nChatBot: {result['answer']}")
    # Optional: Print source documents
    # for source in result['source_documents']:
    #     print(source)

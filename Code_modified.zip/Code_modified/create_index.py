from decouple import config
from langchain_community.document_loaders.chromium import AsyncChromiumLoader
from langchain_community.document_loaders.url_selenium import SeleniumURLLoader
from langchain_community.document_transformers.beautiful_soup_transformer import BeautifulSoupTransformer
from langchain_community.vectorstores.faiss import FAISS
from langchain_mistralai import MistralAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings,ChatOpenAI
import aiohttp
from bs4 import BeautifulSoup
import os
import nest_asyncio
nest_asyncio.apply()
os.environ['OPENAI_API_KEY'] = "---------"

# Load document from URLs
def load_documents_from_urls(urls):
    # Load HTML
    loader = AsyncChromiumLoader([urls])
    html = loader.load()
       
    # Transform
    bs_transformer = BeautifulSoupTransformer()
    docs_transformed = bs_transformer.transform_documents(html,
                                                          unwanted_tags=["script", "style", "header", "footer"],
                                                          tags_to_extract=["body"])
    # Result
    return docs_transformed


# Split documents
def split_documents(documents):
    splitter = RecursiveCharacterTextSplitter(chunk_size=1500, chunk_overlap=150)
    texts = splitter.split_documents(documents)
    return texts


# Index site
def index_site(texts):
     
    db = FAISS.from_documents(texts, OpenAIEmbeddings())
    db.save_local("C:\ennvee_B\Code\Webpage project\Q&A_LLM\SiteChatBotCPU")


# Create index
def create_index(urls):
    documents = load_documents_from_urls(urls)
    texts = split_documents(documents)
    index_site(texts)
